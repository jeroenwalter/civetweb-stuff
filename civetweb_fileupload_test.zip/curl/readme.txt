run these cmd files while running the civetweb example ex_embedded_c (disable ssl first)
